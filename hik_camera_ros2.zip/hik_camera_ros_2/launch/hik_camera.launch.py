import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    
    pkg_share = get_package_share_directory('hik_camera_ros2')
    params_file = os.path.join(pkg_share, 'config', 'params.yaml')

    # 1. 定义相机节点 (你已经有了)
    hik_camera_node = Node(
        package='hik_camera_ros2',
        executable='hik_camera_node',
        parameters=[params_file]
    )

    # 2. 【新增】定义 Rviz2 节点
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        # 你还可以加载一个预先配置好的 .rviz 文件，这样 Rviz2 启动后就自动添加了 Image display
        # arguments=['-d', os.path.join(pkg_share, 'rviz', 'camera_view.rviz')]
    )

    # 3. 将所有要启动的节点都放入 LaunchDescription 中
    return LaunchDescription([
        hik_camera_node,
        rviz_node  # <-- 把 rviz_node 加进去
    ])
